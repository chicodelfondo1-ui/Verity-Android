package com.verity.assistant;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class FaceView extends View {
    public enum Mood { HAPPY, LISTENING, THINKING, WINK, LAUGH, NEUTRAL, SURPRISED, SAD, ANGRY }
    private final Paint p = new Paint(3);
    private Mood mood = Mood.HAPPY;
    private final int yellow = 0xFFFFE51A; // Un solo tono para todas las expresiones
    public FaceView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
    public void setMood(Mood m) { mood=m; invalidate(); }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float s=Math.min(getWidth(),getHeight()), cx=getWidth()/2f, cy=getHeight()/2f, r=s*.47f;
        p.setColor(yellow); p.setStyle(Paint.Style.FILL); c.drawCircle(cx,cy,r,p);
        p.setColor(0xFFB6A500); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(2,s*.012f)); c.drawCircle(cx,cy,r,p);
        p.setColor(0xFF080808); p.setStyle(Paint.Style.FILL);
        float eyeY=cy-r*.22f, eyeX=r*.34f, eyeW=r*.13f, eyeH=r*.28f;
        if(mood==Mood.SURPRISED){ eyeH*=1.2f; }
        if(mood==Mood.ANGRY){ eyeH*=.55f; }
        c.drawOval(new RectF(cx-eyeX-eyeW/2,eyeY-eyeH/2,cx-eyeX+eyeW/2,eyeY+eyeH/2),p);
        if(mood==Mood.WINK) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(r*.09f); p.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(cx+eyeX-r*.10f,eyeY,cx+eyeX+r*.12f,eyeY,p); p.setStyle(Paint.Style.FILL);
        } else c.drawOval(new RectF(cx+eyeX-eyeW/2,eyeY-eyeH/2,cx+eyeX+eyeW/2,eyeY+eyeH/2),p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(r*.075f);
        float my=cy+r*.30f;
        switch(mood){
            case NEUTRAL: c.drawLine(cx-r*.48f,my,cx+r*.48f,my,p); break;
            case SAD: case ANGRY:
                c.drawArc(new RectF(cx-r*.38f,my-r*.05f,cx+r*.38f,my+r*.42f),200,140,false,p); break;
            case SURPRISED:
                p.setStyle(Paint.Style.FILL); c.drawOval(new RectF(cx-r*.15f,my-r*.12f,cx+r*.15f,my+r*.35f),p); break;
            case LAUGH:
                p.setStyle(Paint.Style.FILL); c.drawOval(new RectF(cx-r*.42f,my-r*.08f,cx+r*.42f,my+r*.48f),p);
                p.setColor(0xFFFFFFFF); c.drawRoundRect(new RectF(cx-r*.31f,my-r*.03f,cx+r*.31f,my+r*.12f),r*.05f,r*.05f,p); break;
            default:
                c.drawArc(new RectF(cx-r*.53f,my-r*.43f,cx+r*.53f,my+r*.45f),12,156,false,p);
        }
        p.setStyle(Paint.Style.FILL);
    }
}
