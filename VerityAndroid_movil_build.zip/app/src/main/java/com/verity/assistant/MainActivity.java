package com.verity.assistant;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.Manifest;
import android.content.pm.PackageManager;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private TextView conversation;
    private FaceView face;
    private EditText input;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(0xFF151515);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,24,24,24); root.setGravity(Gravity.CENTER_HORIZONTAL);
        face=new FaceView(this); root.addView(face,new LinearLayout.LayoutParams(180,180));
        TextView title=new TextView(this); title.setText("VERITY"); title.setTextColor(0xFFFFE51A); title.setTextSize(28); title.setGravity(Gravity.CENTER); root.addView(title);
        conversation=new TextView(this); conversation.setText("¡Hola! Soy Verity. Tocá el micrófono o escribime."); conversation.setTextColor(-1); conversation.setTextSize(17); conversation.setPadding(8,28,8,28); root.addView(conversation);
        input=new EditText(this); input.setHint("Escribile a Verity..."); input.setTextColor(-1); input.setHintTextColor(0xFFAAAAAA); root.addView(input,new LinearLayout.LayoutParams(-1,-2));
        Button send=new Button(this); send.setText("Enviar"); root.addView(send); send.setOnClickListener(v->reply(input.getText().toString()));
        Button mic=new Button(this); mic.setText("🎙 Hablar"); root.addView(mic); mic.setOnClickListener(v->listen());
        Button overlay=new Button(this); overlay.setText("Activar burbuja flotante"); root.addView(overlay); overlay.setOnClickListener(v->enableOverlay());
        setContentView(root);
        tts=new TextToSpeech(this, status->{ if(status==TextToSpeech.SUCCESS) tts.setLanguage(new Locale("es","AR")); });
        if(SpeechRecognizer.isRecognitionAvailable(this)) recognizer=SpeechRecognizer.createSpeechRecognizer(this);
    }
    private void enableOverlay() {
        if(!Settings.canDrawOverlays(this)){ Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i); return; }
        startService(new Intent(this,OverlayService.class));
        Toast.makeText(this,"Burbuja Verity activada",Toast.LENGTH_SHORT).show();
    }
    private void listen() {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10); return; }
        if(recognizer==null){ Toast.makeText(this,"Reconocimiento de voz no disponible en este dispositivo",Toast.LENGTH_LONG).show(); return; }
        face.setMood(FaceView.Mood.LISTENING);
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"es-AR");
        recognizer.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float f){} public void onBufferReceived(byte[] b){}
            public void onEndOfSpeech(){face.setMood(FaceView.Mood.THINKING);} public void onError(int e){face.setMood(FaceView.Mood.HAPPY); conversation.setText("No te escuché bien. Probá otra vez.");}
            public void onResults(Bundle b){ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty()) reply(a.get(0));}
            public void onPartialResults(Bundle b){} public void onEvent(int t,Bundle b){}
        });
        recognizer.startListening(i);
    }
    private void reply(String raw) {
        String q=raw==null?"":raw.trim(); if(q.isEmpty()) return;
        input.setText(""); face.setMood(FaceView.Mood.THINKING);
        String l=q.toLowerCase(Locale.ROOT), answer;
        if(l.contains("hola")||l.contains("buen día")||l.contains("buenas")) {answer="¡Hola! ¿Qué hacemos hoy?"; face.setMood(FaceView.Mood.HAPPY);}
        else if(l.contains("gracias")) {answer="¡De nada! Para eso estoy."; face.setMood(FaceView.Mood.WINK);}
        else if(l.contains("chiste")) {answer="¿Qué hace un creeper cuando se enoja? ¡Explota de emoción!"; face.setMood(FaceView.Mood.LAUGH);}
        else if(l.contains("cómo estás")||l.contains("como estas")) {answer="Estoy funcionando y listo para charlar. ¿Y vos?"; face.setMood(FaceView.Mood.HAPPY);}
        else {answer="Te escuché decir: "+q+". En esta primera versión todavía no tengo conectado un servicio de inteligencia artificial, pero ya puedo escucharte y hablarte."; face.setMood(FaceView.Mood.NEUTRAL);}
        conversation.setText("Vos: "+q+"\n\nVerity: "+answer);
        if(tts!=null) tts.speak(answer,TextToSpeech.QUEUE_FLUSH,null,"verity");
    }
    @Override protected void onDestroy(){ if(recognizer!=null) recognizer.destroy(); if(tts!=null) tts.shutdown(); super.onDestroy(); }
}
