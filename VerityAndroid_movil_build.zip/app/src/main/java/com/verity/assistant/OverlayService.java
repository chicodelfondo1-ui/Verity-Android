package com.verity.assistant;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.View;
import android.view.MotionEvent;
import android.widget.Toast;

public class OverlayService extends Service {
    private WindowManager wm; private View bubble; private WindowManager.LayoutParams params;
    @Override public void onCreate(){
        super.onCreate();
        if(!Settings.canDrawOverlays(this)){stopSelf();return;}
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        FaceView face=new FaceView(this); face.setMood(FaceView.Mood.HAPPY); bubble=face;
        int type=android.os.Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        params=new WindowManager.LayoutParams(76,76,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START; params.x=24; params.y=180;
        face.setOnClickListener(v->{ Intent i=new Intent(this,MainActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); });
        face.setOnTouchListener(new View.OnTouchListener(){
            int sx,sy,ox,oy; long down;
            public boolean onTouch(View v,MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=(int)e.getRawX();sy=(int)e.getRawY();ox=params.x;oy=params.y;down=System.currentTimeMillis();return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=ox+(int)e.getRawX()-sx;params.y=oy+(int)e.getRawY()-sy;wm.updateViewLayout(bubble,params);return true;}
                if(e.getAction()==MotionEvent.ACTION_UP){if(Math.abs(e.getRawX()-sx)<10&&Math.abs(e.getRawY()-sy)<10){Intent i=new Intent(OverlayService.this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}return true;}return false;
            }});
        wm.addView(bubble,params);
    }
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){if(wm!=null&&bubble!=null)wm.removeView(bubble);super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
