# VERITY Android (prototipo 0.1)

Proyecto Android Studio en Kotlin/Java (Java) con:
- Burbuja amarilla flotante mediante permiso de superposición.
- Caras dibujadas con el mismo amarillo y distintas expresiones.
- Conversación básica por texto y reconocimiento de voz al tocar el micrófono.
- Respuesta hablada con TextToSpeech del dispositivo.

## Abrir y compilar
1. Instalar Android Studio en una computadora.
2. Abrir la carpeta `VerityAndroid`.
3. Dejar que Gradle sincronice (requiere conexión a internet para descargar dependencias).
4. Conectar un Android o crear un emulador.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Permisos
Al iniciar, permitir micrófono cuando se solicite y habilitar "Mostrar sobre otras apps" desde el botón de burbuja flotante.

## Limitaciones honestas de esta primera versión
- No incluye activación continua por palabra clave "Verity"; se activa tocando el micrófono.
- Las respuestas son básicas y locales; no hay un modelo de IA conectado todavía.
- La burbuja abre la conversación; no controla otras apps.
- La voz usa el motor TTS instalado en Android, no una voz clonada del personaje.
- El servicio de superposición está pensado como prototipo; Android puede limitarlo según fabricante/versión.

La conexión a IA, palabra de activación y acciones seguras entre aplicaciones quedan para una siguiente etapa. Nunca incluyas claves privadas de API dentro de una APK.

## Compilar sin computadora (desde un celular)
Este proyecto incluye GitHub Actions. Sube el contenido del ZIP a un repositorio de GitHub y ejecuta Actions > Build VERITY APK > Run workflow. Al terminar, descarga el artefacto `VERITY-debug-APK` y dentro estará `app-debug.apk`.
